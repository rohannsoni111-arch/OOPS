import java.util.Scanner;
public class lab2a {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter three numbers :- ");
        float x = sc.nextFloat();
        float y = sc.nextFloat();
        float z = sc.nextFloat();

        if(x>y && x>z)
        {
            System.out.println(x+" is greater than "+y+" and "+z);
        }
        else if(y>x && y>z)
        {
            System.out.println(y+" is greater than "+x+" and "+z);
        }
        else {
            System.out.println(z+" is greater than "+x+" and "+y);
        }
        sc.close();
    }
}
