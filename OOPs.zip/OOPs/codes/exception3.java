public class exception3 {
    public static void main(String[] args) {
        try {
            int a = 100/0;
        } catch (ArithmeticException e) {
            System.out.println("I am handling the Exception..");
            System.out.println(e);
        }
        finally{
                System.out.println("\nJava Runtime is handling the Exception...");
                int x[] = {1,2,34};
                x[14] = 100; 
                System.out.println(x);
        }
    }
}
