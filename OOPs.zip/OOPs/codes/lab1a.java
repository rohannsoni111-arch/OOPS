import java.util.Scanner;
public class lab1a {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // to take input form user...
        System.out.println("Enter your name : -");
        String name = sc.nextLine();
        System.out.println("Enter your Roll no : -");
        int roll = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter your Section : ");
        String section = sc.nextLine();
        System.out.println("Enter your branch : -");
        String branch = sc.nextLine();

        //to display the details..
        System.out.println("Name = "+ name);
        System.out.println("Roll = "+roll);
        System.out.println("Section = "+section);
        System.out.println("branch = "+branch);

        sc.close();
    }
}
