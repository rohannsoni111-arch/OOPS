import java.util.Scanner;

public class lab2b {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter 10 numbers :- ");
        int num[] = new int[10];
        for(int i = 0;i<10;i++)
        {
            num[i] = sc.nextInt();
        }
        int odd = 0;
        int even = 0;
        for(int i = 0;i<10;i++)
        {
            if(num[i] %2 == 0)
            {
                even++;
            }
            else{
                odd++;
            }
        }
        System.out.println("The number of Even : "+even);
        System.out.println("The number of Odd : "+odd);
        sc.close();
    }    
}
