import java.util.Scanner;

public class lab1e {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your First name :- ");
        String first = sc.nextLine();
        // sc.nextLine();
        System.out.println("Enter second name = ");
        String last = sc.nextLine();
        
        String name = last.concat(" "+first);

        System.out.println(name);
        sc.close();
    }    
}
