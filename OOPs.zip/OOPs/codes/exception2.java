public class exception2 {
    public static void main(String[] args) {
        System.out.println("Try programiz.pro");
        try {
            int arr[] = { 1, 2, 3 };
            arr[10] = 99;
            try {
                int a = 10;
                int b = 0;
                int x = a / b;
            } catch (ArithmeticException e) {
                System.out.println(e);
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e);
        } catch (IndexOutOfBoundsException e) {
            System.out.println(e);
        } finally {
            for (int i = 1; i <= 5; i++) {
                for (int j = 1; j <= i; j++) {
                    System.out.print("* ");
                }
                System.out.println("\n");
            }
        }
    }
}
