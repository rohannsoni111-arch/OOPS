import java.util.Scanner;
public class lab1d {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter  a number :- ");
        int num = sc.nextInt();

        int original = num;
        int reverse = 0;

        while(num != 0)
        {
            int digit = num %10;
            reverse = reverse * 10 + digit;
            num = num / 10;
        }
        if(reverse == original)
        {
            System.out.println("The Number "+original+" is Palindrome...");
        }
        else{
            System.out.println("The number is not palindrome...");
        }

    }
}
