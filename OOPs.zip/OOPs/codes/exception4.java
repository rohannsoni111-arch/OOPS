public class exception4 {
    public static void main(String[] args) {
        int n = args.length;
        try {
            if(n == 0) throw new ArithmeticException();
            int x = 100/0;
            try {
                if(n == 1) throw new ArrayIndexOutOfBoundsException();
                int arr[] = {1,2,3};
                arr[10] = 99;
                try {
                    if(Integer.parseInt(args[1]) == -1)
                    {
                        throw new ArithmeticException();
                    }
                    else{
                        int fact = 1;
                        for(int i = 1;i<Integer.parseInt(args[1]);i++)
                        {
                            fact = fact * i;
                        }
                        System.out.println("Fact = "+fact);
                    }
                } catch (ArithmeticException e) {
                    System.out.println("Arithmetic... ");
                    System.out.println(e);
                }
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Array out of bound...");
                System.out.println(e);
            }
        } catch (ArithmeticException e) {
            System.out.println("Not divisible by 0");
            System.out.println(e);
        }
    }
}
