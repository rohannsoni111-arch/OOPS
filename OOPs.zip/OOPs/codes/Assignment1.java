// -Write a program to print your name, roll no, section and branch in separate lines.
import java.util.Scanner;
public class Assignment1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your name :- ");
        String name = sc.nextLine();
        System.out.printf("Enter your Roll_no :- ");
        int roll = sc.nextInt();
        System.out.printf("Enter your Section :- \n");
        sc.nextLine();
        String section = sc.nextLine();
        System.out.printf("Enter Your branch : -");
        String branch = sc.next();
        System.out.println("Name = "+ name);
        System.out.println("Roll = "+roll);
        System.out.println("Section = "+ section);
        System.out.println("Branch = "+ branch);
        sc.close();
    }
}
